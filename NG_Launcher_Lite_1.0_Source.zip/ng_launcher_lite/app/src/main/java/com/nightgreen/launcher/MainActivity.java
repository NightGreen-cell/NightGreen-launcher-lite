package com.nightgreen.launcher;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(5, 8, 7);
    private final int PANEL = Color.rgb(15, 23, 19);
    private final int GREEN = Color.rgb(139, 255, 0);
    private final int SILVER = Color.rgb(220, 226, 224);
    private GridLayout appGrid;
    private EditText search;
    private TextView clock;
    private final List<ResolveInfo> apps = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable clockTask = new Runnable() {
        @Override public void run() {
            if (clock != null) {
                clock.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()));
            }
            handler.postDelayed(this, 30000L);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        loadApps();
        buildScreen();
        handler.post(clockTask);
    }

    @Override protected void onResume() {
        super.onResume();
        if (appGrid != null) renderApps(search == null ? "" : search.getText().toString());
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(clockTask);
        super.onDestroy();
    }

    private void loadApps() {
        Intent query = new Intent(Intent.ACTION_MAIN);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = getPackageManager().queryIntentActivities(query, 0);
        for (ResolveInfo item : found) {
            if (!item.activityInfo.packageName.equals(getPackageName())) apps.add(item);
        }
        apps.sort((a, b) -> a.loadLabel(getPackageManager()).toString()
                .compareToIgnoreCase(b.loadLabel(getPackageManager()).toString()));
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(12), dp(18), dp(8));
        root.setBackgroundColor(BG);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("NG  /  NIGHTGREEN", 13, SILVER, true);
        brand.setLetterSpacing(.12f);
        header.addView(brand, new LinearLayout.LayoutParams(0, dp(34), 1));
        header.addView(text("LITE  1.0", 10, GREEN, true));
        root.addView(header);

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setGravity(Gravity.CENTER);
        hero.setPadding(dp(8), dp(16), dp(8), dp(16));
        clock = text(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()), 48, Color.WHITE, true);
        hero.addView(clock);
        hero.addView(text(new SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(new Date()).toUpperCase(Locale.getDefault()), 12, SILVER, false));
        TextView wolf = text("NG", 42, GREEN, true);
        wolf.setGravity(Gravity.CENTER);
        wolf.setPadding(0, dp(8), 0, dp(2));
        hero.addView(wolf);
        hero.addView(text("NIGHTGREEN", 22, SILVER, true));
        hero.addView(text("BUILDING TOMORROW, TODAY.", 10, GREEN, true));
        root.addView(hero);

        LinearLayout searchBox = new LinearLayout(this);
        searchBox.setGravity(Gravity.CENTER_VERTICAL);
        searchBox.setPadding(dp(12), 0, dp(10), 0);
        searchBox.setBackground(round(PANEL, GREEN, 1));
        searchBox.addView(text("⌕", 25, GREEN, true));
        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextColor(Color.WHITE);
        search.setHintTextColor(Color.rgb(135, 148, 140));
        search.setHint("Rechercher une application...");
        search.setTextSize(14);
        search.setBackgroundColor(Color.TRANSPARENT);
        search.setPadding(dp(10), dp(10), dp(4), dp(10));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) { }
            @Override public void onTextChanged(CharSequence s, int st, int before, int count) { renderApps(s.toString()); }
            @Override public void afterTextChanged(Editable e) { }
        });
        searchBox.addView(search, new LinearLayout.LayoutParams(0, dp(48), 1));
        root.addView(searchBox);

        LinearLayout section = new LinearLayout(this);
        section.setGravity(Gravity.CENTER_VERTICAL);
        section.setPadding(0, dp(14), 0, dp(6));
        section.addView(text("APPLICATIONS", 12, SILVER, true), new LinearLayout.LayoutParams(0, dp(28), 1));
        section.addView(text(apps.size() + " APPS", 10, GREEN, false));
        root.addView(section);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        appGrid = new GridLayout(this);
        appGrid.setColumnCount(4);
        scroll.addView(appGrid);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        LinearLayout footer = new LinearLayout(this);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(8), 0, dp(2));
        footer.addView(action("⚙", "PARAMÈTRES", () -> startActivity(new Intent(Settings.ACTION_SETTINGS))), new LinearLayout.LayoutParams(0, dp(52), 1));
        footer.addView(action("◈", "FOND NG", this::setWallpaper), new LinearLayout.LayoutParams(0, dp(52), 1));
        footer.addView(action("⌂", "ACCUEIL", () -> search.setText("")), new LinearLayout.LayoutParams(0, dp(52), 1));
        root.addView(footer);

        setContentView(root);
        renderApps("");
    }

    private void renderApps(String filter) {
        if (appGrid == null) return;
        appGrid.removeAllViews();
        int shown = 0;
        for (ResolveInfo info : apps) {
            String label = info.loadLabel(getPackageManager()).toString();
            if (!label.toLowerCase(Locale.getDefault()).contains(filter.toLowerCase(Locale.getDefault()))) continue;
            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(Gravity.CENTER);
            tile.setPadding(dp(3), dp(8), dp(3), dp(8));
            tile.setFocusable(true);
            tile.setClickable(true);
            tile.setOnClickListener(v -> launchApp(info));

            ImageView icon = new ImageView(this);
            try { icon.setImageDrawable(info.loadIcon(getPackageManager())); }
            catch (Exception ignored) { }
            icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            icon.setPadding(dp(10), dp(10), dp(10), dp(10));
            icon.setBackground(round(PANEL, Color.rgb(49, 91, 55), 1));
            tile.addView(icon, new LinearLayout.LayoutParams(dp(48), dp(48)));

            TextView name = text(label, 10, SILVER, false);
            name.setGravity(Gravity.CENTER);
            name.setMaxLines(2);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            name.setPadding(0, dp(5), 0, 0);
            tile.addView(name, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(32)));

            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = 0;
            params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            params.setMargins(dp(1), dp(1), dp(1), dp(1));
            appGrid.addView(tile, params);
            shown++;
        }
        if (shown == 0) {
            TextView empty = text("Aucune application trouvée", 13, SILVER, false);
            empty.setPadding(dp(12), dp(20), 0, 0);
            appGrid.addView(empty);
        }
    }

    private void launchApp(ResolveInfo info) {
        Intent intent = getPackageManager().getLaunchIntentForPackage(info.activityInfo.packageName);
        if (intent != null) startActivity(intent);
        else Toast.makeText(this, "Application indisponible", Toast.LENGTH_SHORT).show();
    }

    private void setWallpaper() {
        try {
            WallpaperManager.getInstance(this).setResource(R.drawable.ng_wallpaper);
            Toast.makeText(this, "Fond d'écran NG appliqué", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Impossible de modifier le fond d'écran", Toast.LENGTH_SHORT).show();
        }
    }

    private View action(String symbol, String label, Runnable click) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setOnClickListener(v -> click.run());
        TextView icon = text(symbol, 21, GREEN, true);
        icon.setGravity(Gravity.CENTER);
        box.addView(icon);
        TextView caption = text(label, 8, SILVER, true);
        caption.setGravity(Gravity.CENTER);
        box.addView(caption);
        return box;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private GradientDrawable round(int color, int stroke, int width) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(13));
        d.setStroke(dp(width), stroke);
        return d;
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + .5f); }
}
