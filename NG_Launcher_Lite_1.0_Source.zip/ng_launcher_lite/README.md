# NG Launcher Lite 1.0

A small, native Android home-screen launcher for Nightgreen Corporation. It uses Java and Android platform widgets only: no Kotlin, Jetpack Compose, third-party runtime libraries, network permission, analytics, or account system.

## Features
- Declares itself as an Android HOME launcher and regular app.
- Lists launchable apps and their icons from the device's package manager.
- Launches apps when tapped.
- Filters the app list locally.
- Shows local time and date.
- Opens Android Settings.
- Can apply the bundled NG wallpaper.

## Device-oriented choices
- Minimum Android version: Android 6.0 (API 23).
- No internet permission.
- No background service or animation loop beyond a low-frequency clock refresh while open.
- No Compose/Kotlin runtime dependencies.
- App grid is populated from apps installed on the phone.

This is a lightweight starting point, not a promise that every device with 2 GB RAM will run it perfectly. Available memory, Android version, and the phone manufacturer's software can affect performance.

## Build the APK using GitHub Actions (phone only; cloud compilation)
1. Create or sign in to a GitHub account in your phone browser.
2. Create a new repository, for example `ng-launcher-lite`.
3. Upload this ZIP to the repository root and name it `source.zip`.
4. In the repository, create `.github/workflows/build-apk.yml` and paste the workflow from the companion file `NG_Launcher_Lite_Build_Workflow.yml`.
5. Open the repository's **Actions** tab and enable workflows if GitHub asks.
6. Select **Build NG Launcher Lite APK**, then **Run workflow**.
7. Wait for the workflow to finish successfully.
8. Open that run, scroll to **Artifacts**, and download `NG-Launcher-Lite-debug`.
9. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
10. Open `app-debug.apk` on Android and install it. If Android prompts, allow installs from the browser/files app used to open the APK.
11. Press Home and choose **NG Launcher Lite** as the default Home app.

The workflow builds a debug APK. It is suitable for personal testing and is not a Play Store release build. The source ZIP contains its own workflow too, but when uploading the ZIP as a single file, create the companion workflow in the repository root using the separate workflow file.

## Build locally
Requires JDK 17, Gradle 8.9, Android SDK platform 35, and Android build tools. Run `gradle assembleDebug` from the project root. Output: `app/build/outputs/apk/debug/app-debug.apk`.

## App identity
- Application ID: `com.nightgreen.launcher`
- Version: `1.0-lite`
- Launcher label: `NG Launcher Lite`

## Privacy
No network permission, no analytics, and no user account. The launcher queries launchable apps locally on the device.
